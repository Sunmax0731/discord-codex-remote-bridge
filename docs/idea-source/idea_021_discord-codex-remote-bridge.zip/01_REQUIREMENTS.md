# Requirements

## Target Users

- A solo developer who owns a Windows development PC and uses Codex for local product development.
- A developer who wants to start or monitor agent work from a smartphone.
- A developer who wants Discord to act as a lightweight project/session surface without exposing the PC broadly.

## User Problems

- Codex local workflows often require sitting at the target PC.
- Smartphone access to local repository state, directory structure, and agent results is weak.
- Remote command channels can become dangerous if authorization, approvals, and audit logs are not designed first.
- Discord conversations are easy to start but hard to translate into durable project/session state.

## Functional Requirements

- Map Discord categories to projects.
- Map Discord text channels to Codex sessions.
- Use Discord threads for individual job logs.
- Accept prompts through slash commands or explicit bot mentions.
- Invoke local Codex from the Windows PC.
- Post progress, final answer, changed files, tests, and errors back to Discord.
- Show repository directories and selected files from Discord.
- Support job cancellation.
- Support approval gates for risky operations.
- Keep an audit trail for all accepted commands and runner results.

## Security Requirements

- Allow only configured Discord users.
- Allow only configured guilds, categories, channels, and repositories.
- Use immutable Discord IDs for authorization.
- Reject paths outside configured repository roots.
- Redact secrets before any Discord post.
- Require manual approval for push, PR, merge, release, deletion, and broad file moves.
- Log denied commands without executing them.

## Non-Functional Requirements

- Windows-first setup.
- Usable from Discord mobile.
- Recoverable after bridge restart.
- One-job-at-a-time default per session.
- Bounded directory output for mobile readability.
- Clear failure messages when Codex, Git, Discord, or filesystem operations fail.

## MVP Out of Scope

- Public multi-tenant SaaS.
- Team permission management beyond a small allowlist.
- General remote shell execution.
- Direct public exposure of Codex app-server.
- Fully automatic merge/release without human approval.
