# TODO

## Phase 1: Foundation

- [ ] Scaffold TypeScript project.
- [ ] Add Discord application setup guide.
- [ ] Add SQLite schema and migrations.
- [ ] Implement project/session mapping by Discord IDs.
- [ ] Add repository allowlist configuration.

## Phase 2: Discord Commands

- [ ] Register `/codex`, `/status`, `/cancel`, `/approve`.
- [ ] Register `/tree`, `/ls`, `/file`.
- [ ] Add mobile-friendly response formatting.
- [ ] Add long-output file attachment support.

## Phase 3: Codex Runner

- [ ] Implement `CodexExecRunner`.
- [ ] Capture stdout, stderr, exit code, duration, and changed files.
- [ ] Add cancellation and timeout handling.
- [ ] Add runner output redaction before Discord posting.

## Phase 4: Safety

- [ ] Add allowed user and allowed channel checks.
- [ ] Add path traversal protection.
- [ ] Add approval policy for risky operations.
- [ ] Add audit log view.

## Phase 5: Validation

- [ ] Unit test command parsing.
- [ ] Unit test redaction and path guards.
- [ ] Integration test with Discord development guild.
- [ ] Run an end-to-end Codex job on a sample repo.
