# Specification

## Core Entities

### Project

- `id`
- `guild_id`
- `category_id`
- `display_name`
- `repo_path`
- `default_branch`
- `allowed_user_ids`
- `approval_policy`
- `created_at`
- `updated_at`

### Session

- `id`
- `project_id`
- `channel_id`
- `codex_thread_id`
- `status`
- `last_job_id`
- `created_at`
- `updated_at`

### Job

- `id`
- `session_id`
- `thread_id`
- `requested_by_user_id`
- `prompt`
- `status`
- `runner_type`
- `started_at`
- `finished_at`
- `exit_code`
- `summary`
- `changed_files_json`
- `test_result`

### Approval

- `id`
- `job_id`
- `kind`
- `requested_by`
- `approved_by`
- `status`
- `created_at`
- `resolved_at`

## Discord Commands

- `/codex prompt:<text>`: create a Codex job in the current project/session.
- `/status`: show current session and latest job status.
- `/cancel job:<id>`: request cancellation.
- `/approve job:<id> action:<kind>`: approve a gated action.
- `/tree path:<path> depth:<number>`: show directory tree.
- `/ls path:<path>`: show directory entries.
- `/file path:<path>`: show a small text file preview or attach it if it is long.
- `/sessions`: list sessions under the current category.

## Execution Flow

1. User invokes a command in an authorized channel.
2. Bridge resolves `guild_id`, `category_id`, and `channel_id`.
3. Bridge loads the project and session from SQLite.
4. Bridge validates user, channel, repository, and path constraints.
5. For `/codex`, Bridge creates a Discord thread and a queued job.
6. Runner invokes Codex with structured context.
7. Bridge streams or periodically posts status updates.
8. Bridge posts final summary, changed files, tests, and approval requests.
9. Audit event is persisted.

## Runner Modes

### MVP: `codex exec`

Use `codex exec` for non-interactive execution. This is simpler to run as a background job and fits scriptable Discord requests.

### Future: Codex SDK

Use Codex SDK when persistent Codex thread control and richer state handling are needed.

### Future: Codex app-server

Use app-server only for deep client integration. Keep it local or behind a secure tunnel; do not publicly expose it in the MVP.

## Directory Browsing Rules

- Paths are relative to the configured repository root.
- Reject absolute paths from Discord input.
- Resolve and verify final paths remain under the repository root.
- Hide ignored folders such as `.git`, `node_modules`, `dist`, `build`, `.venv`, and secrets folders by default.
- Bound output by depth, item count, and message length.
- Attach larger output as Markdown.

## Discord Output Rules

- Keep status messages short.
- Edit one pinned/status message for routine progress.
- Use a thread for detailed job logs.
- Attach large logs, tree output, and patches as files.
- Always include final status, duration, changed files, and tests run.
