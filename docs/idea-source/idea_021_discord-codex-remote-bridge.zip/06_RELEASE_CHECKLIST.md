# Release Checklist

## Before First Internal Release

- [ ] Discord application setup documented.
- [ ] Bot token storage documented and excluded from Git.
- [ ] Windows service or startup command documented.
- [ ] Repository allowlist documented.
- [ ] SQLite migration path tested.
- [ ] `/status`, `/tree`, `/ls`, `/file`, `/codex`, `/approve`, and `/cancel` tested.
- [ ] Unauthorized user test completed.
- [ ] Path traversal test completed.
- [ ] Secret redaction test completed.
- [ ] Codex unavailable error path tested.

## Release Evidence

Capture:

- commit hash
- package version
- Windows version
- Node.js version
- Codex CLI version
- Discord development guild ID masked or documented locally only
- test command output
- end-to-end smoke-test result

## Distribution Boundary

The first release is personal/internal use only. It assumes:

- one owner
- one primary Windows PC
- private Discord server
- configured local repositories
- local Codex authentication

## Post-Release Checks

- Confirm the bridge restarts cleanly.
- Confirm queued jobs do not duplicate after restart.
- Confirm logs do not contain tokens.
- Confirm Discord output is readable from mobile.
- Confirm no command can access paths outside configured repositories.
