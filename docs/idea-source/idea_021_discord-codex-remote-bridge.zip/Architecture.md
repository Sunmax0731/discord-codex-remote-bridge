# Architecture

## Components

```mermaid
flowchart TD
  Discord["Discord Gateway / Interactions"] --> Bot["Command Handlers"]
  Bot --> Auth["Authorization and Policy"]
  Auth --> Mapping["Project and Session Mapping"]
  Mapping --> Queue["SQLite Job Queue"]
  Queue --> Runner["Codex Runner Adapter"]
  Runner --> Repo["Allowed Local Repository"]
  Repo --> Git["Git and Test Commands"]
  Runner --> Redaction["Log Redaction"]
  Redaction --> DiscordOut["Discord Status and Result Posts"]
  Bot --> Fs["Read-only Filesystem Browser"]
  Fs --> DiscordOut
```

## Local Process

The bridge runs on the Windows development PC as one of:

- foreground CLI during development
- Windows service for daily use
- tray app later if visual status is needed

## Storage

SQLite is enough for MVP:

- `projects`
- `sessions`
- `jobs`
- `approvals`
- `audit_events`
- `settings`

## Runner Adapter

```ts
interface CodexRunner {
  run(job: CodexJob, context: RunnerContext): Promise<CodexRunResult>;
  cancel(jobId: string): Promise<void>;
}
```

Runner result includes:

- status
- summary
- stdout/stderr paths
- changed files
- test command results
- approval requests

## Security Boundaries

- Discord input is untrusted.
- Local repository roots are configured, not inferred.
- Path resolution must use canonical absolute paths before access.
- Secrets must never be included in Discord messages.
- App-server or local HTTP endpoints must bind to localhost unless a secure tunnel is explicitly designed.

## Failure Modes

- Discord API failure: persist event and retry bounded times.
- Codex command unavailable: mark job failed with setup guidance.
- Repo locked or dirty: report status and stop before destructive changes.
- Bridge restart: recover queued/running job state and mark interrupted jobs for review.
