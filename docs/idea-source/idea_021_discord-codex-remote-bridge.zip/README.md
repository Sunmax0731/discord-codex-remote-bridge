# discord-codex-remote-bridge

`discord-codex-remote-bridge` is a Windows-first bridge between Discord and local Codex. It lets the owner use Discord from a smartphone or another PC to start, monitor, and approve Codex coding work on a configured Windows machine.

## Product Shape

- Discord server: personal development control surface.
- Discord category: Codex project.
- Discord text channel: Codex session.
- Discord thread: one execution job and its log.
- Local Windows bridge: authorization, queue, Codex invocation, filesystem read-only views, and Discord response posting.

## Core Value

The product turns Discord into a lightweight remote operator panel for personal software development. It does not try to replace Codex App. It focuses on starting work away from the main PC, checking project files from mobile, reviewing the agent result, and approving risky operations deliberately.

## MVP

- Discord slash commands: `/codex`, `/tree`, `/ls`, `/file`, `/status`, `/approve`, `/cancel`.
- Category-to-project and channel-to-session mapping stored in SQLite.
- Local Codex execution through `codex exec` first, with SDK/app-server exploration behind an adapter.
- Discord progress updates and final summaries.
- Read-only directory browsing designed for mobile.
- Approval gate for push, PR, merge, release, and destructive operations.

## Non-Goals

- Public SaaS hosting in the MVP.
- Multi-user team billing.
- Running untrusted arbitrary shell commands from Discord.
- Directly exposing Codex app-server to the public internet.
- Replacing GitHub review or CI.

## Implementation Bias

Start with a Node.js/TypeScript Windows service or tray-resident process using Discord Gateway interactions and a local SQLite job queue. Keep the core runner behind an interface so `codex exec` can be replaced or supplemented by Codex SDK/app-server later.
