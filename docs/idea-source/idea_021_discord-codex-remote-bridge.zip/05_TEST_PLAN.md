# Test Plan

## Unit Tests

- Authorization rejects unknown users.
- Authorization rejects unmapped categories and channels.
- Path resolver rejects absolute paths, `..`, symlinks outside the repo, and hidden secret paths.
- Redaction removes token-like, key-like, and environment-variable-like values.
- Queue preserves job order per session.
- Command parsing handles missing and invalid options.

Expected commands once the repo is scaffolded:

```powershell
npm test
npm run lint
npm run typecheck
```

## Integration Tests

- Register slash commands in a Discord development guild.
- Invoke `/status` in an unmapped channel and confirm a safe error.
- Configure a category as a project and confirm `/status` resolves it.
- Run `/tree depth:2` and confirm output is bounded and mobile-readable.
- Run `/file README.md` and confirm preview size limits.
- Submit `/codex` against a small sample repository.

## End-to-End Smoke Test

1. Start the bridge on Windows.
2. Open Discord mobile.
3. In a mapped session channel, run `/tree`.
4. Run `/codex prompt:"Inspect this repo and summarize the test command."`
5. Confirm a job thread is created.
6. Confirm progress and final result appear in Discord.
7. Confirm audit log contains the command, user, channel, job ID, and result.

## Security Tests

- Try `/file ..\\..\\Users\\...` and confirm denial.
- Try a prompt that asks Codex to print secrets and confirm redaction before Discord posting.
- Try push/merge/release language and confirm approval is required.
- Try an unauthorized Discord user and confirm no job is created.

## Manual Mobile Checks

- Verify tree output fits on phone.
- Verify final job summary is readable without opening attachments.
- Verify attachment names make sense.
- Verify approval buttons are visible and unambiguous.
