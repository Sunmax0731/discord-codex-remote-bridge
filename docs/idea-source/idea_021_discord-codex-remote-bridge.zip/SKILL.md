# SKILL

Use this guide when building or extending `discord-codex-remote-bridge`.

## Start Order

1. Confirm the target repository and Discord development guild.
2. Read the security rules in `AGENTS.md`.
3. Implement one command or runner capability at a time.
4. Add tests for the command, authorization, and failure path.
5. Validate with a local Discord test server before marking the task done.

## Development Flow

- Use TypeScript and keep command handlers typed.
- Keep Codex runner operations behind an adapter:
  - `CodexExecRunner` for MVP.
  - `CodexSdkRunner` for future thread-aware execution.
  - `CodexAppServerRunner` only if the app-server protocol is needed locally.
- Store durable state in SQLite:
  - projects
  - sessions
  - jobs
  - approvals
  - audit_events
- Keep filesystem access under configured repository roots.

## Prompt Handling

- Normalize a Discord request into a structured job:
  - project
  - session
  - user
  - prompt
  - allowed repository
  - approval policy
  - expected output
- Add project/session context before passing the prompt to Codex.
- Include a clear done condition in the Codex prompt.
- Do not forward raw Discord threads that contain unrelated chat unless the user explicitly asks to include them.

## Verification

- Unit test authorization and path safety first.
- Integration test command registration and interaction responses.
- Smoke test a real `/codex` run in a private Discord guild.
- Confirm Discord mobile display for tree output, status updates, and final summaries.
