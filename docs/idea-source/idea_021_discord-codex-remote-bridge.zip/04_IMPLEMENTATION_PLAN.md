# Implementation Plan

## Phase 1: Project Foundation

- Scaffold TypeScript project.
- Add configuration schema.
- Add SQLite migrations.
- Add Discord development guild setup guide.
- Add repository allowlist validation.

## Phase 2: Discord Command MVP

- Implement slash command registration.
- Implement `/status`.
- Implement `/tree`, `/ls`, and `/file`.
- Implement mobile-friendly pagination and attachments.

## Phase 3: Codex Job Execution

- Implement `/codex`.
- Create a Discord job thread.
- Queue the job.
- Invoke `codex exec` in the configured repository.
- Capture result and post summary.

## Phase 4: Safety and Approval

- Add user/channel authorization.
- Add path traversal tests.
- Add redaction pipeline.
- Add `/approve` and `/cancel`.
- Add approval-gated push/PR hooks.

## Phase 5: Operational Hardening

- Add Windows service packaging.
- Add startup health checks.
- Add retry behavior for Discord posting.
- Add audit export.
- Add release documentation and smoke-test checklist.
