# Design Notes

## Primary Screen Is Discord

The user-facing surface is Discord, especially the mobile app. The bridge should not require a rich desktop UI for the MVP. Desktop configuration can be a local config file plus validation command.

## Project Layout In Discord

Recommended layout:

```text
Category: product-a
  #main
  #ui-fixes
  #release

Category: product-b
  #planning
  #implementation
```

- Category name is human-readable only.
- Category ID is the real project key.
- Channel name is human-readable only.
- Channel ID is the real session key.

## Job Message Shape

Each `/codex` command creates or reuses a thread:

```text
[queued] job #42
Project: product-a
Session: ui-fixes
Runner: codex exec
Requested by: owner
```

Final response:

```text
[completed] job #42
Summary:
- Implemented ...
- Updated ...

Changed files:
- src/...

Validation:
- npm test: pass

Needs approval:
- push branch codex/ui-fix
```

## Directory View

Default tree output is compact:

```text
src
├─ app
├─ components
└─ lib
```

Rules:

- Default depth is 2.
- Maximum depth is configurable.
- Large output becomes `tree.md`.
- Hidden and generated folders are omitted unless `include_ignored:true` is explicitly allowed for the owner.

## Approval UX

Risky operations should appear as explicit choices:

- Approve push
- Approve PR creation
- Reject
- Show diff

The bridge should store approval decisions in SQLite and post a short audit message back to the job thread.
