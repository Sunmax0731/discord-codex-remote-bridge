# Design

## Options

### Option A: Discord Bot + `codex exec`

The bridge runs as a Windows background process, listens to Discord interactions, and invokes `codex exec` for each job.

- Pros: simplest MVP, script-friendly, easy to supervise.
- Cons: less rich session continuity than SDK/app-server.

### Option B: Discord Bot + Codex SDK

The bridge controls Codex through SDK threads and maps Discord channels to Codex threads.

- Pros: better session continuity and structured control.
- Cons: more implementation complexity and more dependency on SDK behavior.

### Option C: Discord Bot + Codex app-server

The bridge integrates with the app-server protocol and handles streamed events similar to a custom Codex client.

- Pros: richest client-like integration.
- Cons: highest complexity; WebSocket app-server transport is not the right MVP boundary.

## Criteria

- Safe enough for local PC automation.
- Easy to validate on a single Windows machine.
- Works from Discord mobile.
- Keeps project/session mapping durable.
- Leaves room for richer Codex integration later.

## Chosen Direction

Start with Option A and design the runner as an adapter. This keeps the MVP small and reliable while preserving a path to Option B when persistent thread control becomes necessary.

## Discord Interaction Design

- Use categories as visible project groups.
- Use text channels as session surfaces.
- Use threads as individual job logs.
- Use slash commands for structured input.
- Use buttons for approval and cancellation.
- Use select menus only for bounded project/session choices.

## Mobile Design Principles

- Keep the first response short.
- Prefer status embeds with a small number of fields.
- Put long logs in attachments.
- Use `/tree depth:2` as the default directory view.
- Provide "next page" controls when a directory has many entries.

## Safety Design

- All command handling begins with authorization and mapping resolution.
- All filesystem operations are read-only unless the Codex runner is executing in an approved repo.
- All risky output actions require a separate approval command or button.
- All final responses include enough evidence for the owner to decide the next action.
