# Start Prompt

You are implementing `discord-codex-remote-bridge`, a Windows-first Discord bridge that lets the owner start and supervise local Codex coding sessions from Discord.

## Goal

Build a safe MVP where a Discord category maps to a Codex project, a Discord text channel maps to a session, and a Discord thread maps to one job log. The bridge must run on the owner's Windows PC, accept only authorized Discord users and channels, invoke Codex through the local CLI/SDK, and post progress, summaries, diffs, test results, and directory listings back to Discord.

## Required Reading

1. `AGENTS.md`
2. `SKILL.md`
3. `01_REQUIREMENTS.md`
4. `02_SPECIFICATION.md`
5. `03_DESIGN.md`
6. `Architecture.md`
7. `TODO.md`

## MVP Constraints

- Use Discord slash commands and explicit bot mentions; do not rely on reading every channel message.
- Store mappings by Discord IDs, not mutable names.
- Keep execution on a configured allowlist of local repositories.
- Run one Codex job per session by default.
- Require explicit approval before push, PR creation, merge, release, deletion, or broad filesystem changes.
- Make directory browsing read-only and bounded by depth, item count, file size, and ignored paths.
- Redact secrets from logs before posting to Discord.

## Done When

- A configured Discord project/session can submit a prompt to local Codex.
- The bridge posts job status, final response, changed-file summary, and test result back to Discord.
- `/tree`, `/ls`, and `/file` work from a smartphone-friendly Discord UI.
- Authorization, audit logging, cancellation, and approval gates are implemented and tested.
