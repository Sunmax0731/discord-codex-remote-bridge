# AGENTS

This repository is a safety-sensitive local automation bridge. Treat every Discord input as remote input that can cause local code and command execution if mishandled.

## Operating Rules

- Read `SKILL.md`, `01_REQUIREMENTS.md`, `02_SPECIFICATION.md`, `03_DESIGN.md`, and `Architecture.md` before implementation.
- Keep the bridge Windows-first and local-owner-first.
- Store Discord mappings by immutable IDs: `guild_id`, `category_id`, `channel_id`, `thread_id`, and `user_id`.
- Never trust Discord display names, channel names, or category names as security boundaries.
- Default to read-only inspection unless a command explicitly creates a Codex job.
- Require approval for push, PR creation, merge, release, deletion, broad file moves, and secret-affecting operations.
- Redact tokens, environment variables, private keys, and credential-looking strings before posting logs to Discord.
- Keep job execution isolated per repository and session.

## Expected Project Structure

- `src/discord`: Discord bot, slash commands, interactions, and message formatting.
- `src/codex`: Codex runner adapters.
- `src/projects`: project/session mapping and repository allowlist.
- `src/filesystem`: read-only directory and file preview commands.
- `src/jobs`: queue, lifecycle, cancellation, and audit log.
- `src/security`: authorization, approval policy, redaction, and path guards.
- `docs`: setup, threat model, and release evidence.

## Quality Bar

- Add tests for authorization, path traversal prevention, log redaction, queue behavior, and Discord command parsing.
- Prefer small, explicit command handlers over a broad natural-language command router.
- Keep Discord output concise; attach long logs as files.
- Do not introduce cloud dependencies into the MVP unless they are required for Discord operation.
